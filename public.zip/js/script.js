(function () {
  const navBtn = document.querySelector(".header-navbar-btn");
  navBtn.addEventListener("click", function () {
    this.classList.toggle("active");
  })
})();